# Kingdoms & Lords HD Remaster — Proyek Android 2D Isometrik

## Spesifikasi
- Android native: Kotlin + Android Canvas
- Orientasi: landscape
- Minimum Android: Android 10 (API 29)
- Target SDK: 35
- Tampilan: peta isometrik 2D dengan kastil, rumah, ladang, pepohonan, dan panel sumber daya.
- Interaksi prototipe: bangun rumah, bangun ladang, rekrut pasukan, serbu bandit.

## Cara membuat APK dari HP Android (tanpa komputer)
Cara paling praktis adalah memakai GitHub Actions:
1. Masuk ke github.com dan buat repository baru. Sebaiknya pilih Private.
2. Ekstrak ZIP proyek ini di HP, lalu upload seluruh isi folder ke repository. Pastikan folder `.github/workflows` ikut ter-upload.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Android APK**, lalu tekan **Run workflow**.
5. Tunggu sampai workflow selesai dengan status hijau.
6. Buka hasil run dan unduh artifact `KingdomsLords-HD-Android10-APK`.
7. Ekstrak artifact ZIP dan pasang `app-debug.apk` pada HP.

## Membuka di Android Studio
Buka folder proyek, lakukan Gradle Sync, lalu jalankan `assembleDebug`.

## Catatan penting
Ini adalah prototipe native baru dengan ilustrasi placeholder yang digambar memakai Canvas.
Ini belum merupakan porting penuh game komersial Kingdoms & Lords dan tidak menyertakan kode/aset proprietary Gameloft.
Untuk membuat versi remaster yang lebih setia, diperlukan pengembangan lebih lanjut dan hak penggunaan aset yang sesuai.

package com.kingdomslords.isometric

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

class KingdomView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cols = 11
    private val rows = 8
    private var gold = 350
    private var food = 220
    private var wood = 180
    private var troops = 12
    private var houses = 2
    private var farms = 1
    private var selectedAction = 0
    private var toast = "Pilih lahan, lalu bangun kerajaanmu!"
    private var toastUntil = 0L
    private var mapOriginX = 0f
    private var mapOriginY = 0f
    private var tileW = 0f
    private var tileH = 0f
    private val buildings = mutableMapOf<Pair<Int,Int>, Int>()

    init {
        // Starting settlement around the central castle.
        buildings[5 to 3] = 1 // castle
        buildings[3 to 3] = 2 // house
        buildings[7 to 4] = 3 // farm
        buildings[4 to 5] = 4 // lumber camp
        isFocusable = true
    }

    private fun fill(c: Int) { paint.color = c; paint.style = Paint.Style.FILL; paint.strokeWidth = 1f }
    private fun stroke(c: Int, sw: Float = 1f) { paint.color = c; paint.style = Paint.Style.STROKE; paint.strokeWidth = sw }
    private fun poly(canvas: Canvas, pts: FloatArray, color: Int) {
        val path = Path()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) { path.lineTo(pts[i], pts[i+1]); i += 2 }
        path.close(); fill(color); canvas.drawPath(path, paint)
    }
    private fun txt(canvas: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Color.WHITE) {
        fill(color); paint.textSize = size; paint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        canvas.drawText(s, x, y, paint)
    }
    private fun rr(canvas: Canvas, rect: RectF, radius: Float, color: Int) {
        fill(color); canvas.drawRoundRect(rect, radius, radius, paint)
    }
    private fun diamond(canvas: Canvas, cx: Float, cy: Float, w: Float, h: Float, color: Int, edge: Int? = null) {
        poly(canvas, floatArrayOf(cx,cy-h/2, cx+w/2,cy, cx,cy+h/2, cx-w/2,cy), color)
        if (edge != null) {
            stroke(edge, 1.1f)
            val path=Path().apply { moveTo(cx,cy-h/2); lineTo(cx+w/2,cy); lineTo(cx,cy+h/2); lineTo(cx-w/2,cy); close() }
            canvas.drawPath(path,paint)
        }
    }
    private fun iso(x: Int, y: Int): Pair<Float,Float> {
        return Pair(mapOriginX + (x-y)*tileW/2f, mapOriginY + (x+y)*tileH/2f)
    }
    private fun drawTree(canvas: Canvas, x: Float, y: Float, scale: Float) {
        fill(Color.rgb(91,65,42)); canvas.drawRect(x-2*scale,y-10*scale,x+2*scale,y+5*scale,paint)
        fill(Color.rgb(35,105,59)); canvas.drawCircle(x,y-16*scale,10*scale,paint)
        fill(Color.rgb(54,133,67)); canvas.drawCircle(x-5*scale,y-19*scale,6*scale,paint)
        fill(Color.rgb(72,151,76)); canvas.drawCircle(x+5*scale,y-20*scale,6*scale,paint)
    }
    private fun drawHouse(canvas: Canvas, x: Float, y: Float, s: Float) {
        // shaded walls
        poly(canvas,floatArrayOf(x-13*s,y-17*s,x,y-10*s,x,y+8*s,x-13*s,y+1*s),Color.rgb(174,123,75))
        poly(canvas,floatArrayOf(x,y-10*s,x+13*s,y-17*s,x+13*s,y+1*s,x,y+8*s),Color.rgb(128,83,55))
        poly(canvas,floatArrayOf(x-15*s,y-18*s,x,y-29*s,x+15*s,y-18*s,x,y-9*s),Color.rgb(145,55,45))
        poly(canvas,floatArrayOf(x,y-29*s,x+15*s,y-18*s,x+4*s,y-12*s,x-11*s,y-21*s),Color.rgb(177,69,51))
        fill(Color.rgb(67,49,39)); canvas.drawRect(x-3*s,y-3*s,x+3*s,y+8*s,paint)
    }
    private fun drawCastle(canvas: Canvas, x: Float, y: Float, s: Float) {
        // castle base with two shaded sides and central keep
        poly(canvas,floatArrayOf(x-27*s,y-25*s,x,y-11*s,x,y+12*s,x-27*s,y-2*s),Color.rgb(166,164,151))
        poly(canvas,floatArrayOf(x,y-11*s,x+27*s,y-25*s,x+27*s,y-2*s,x,y+12*s),Color.rgb(126,129,124))
        poly(canvas,floatArrayOf(x-18*s,y-27*s,x,y-38*s,x+18*s,y-27*s,x,y-17*s),Color.rgb(146,51,44))
        poly(canvas,floatArrayOf(x-18*s,y-27*s,x,y-17*s,x,y-3*s,x-18*s,y-13*s),Color.rgb(193,190,170))
        poly(canvas,floatArrayOf(x,y-17*s,x+18*s,y-27*s,x+18*s,y-13*s,x,y-3*s),Color.rgb(151,151,137))
        fill(Color.rgb(88,58,43)); canvas.drawRect(x-4*s,y-8*s,x+4*s,y+11*s,paint)
        fill(Color.rgb(226,190,92)); canvas.drawRect(x+1*s,y-35*s,x+2.5f*s,y-48*s,paint)
        poly(canvas,floatArrayOf(x+2*s,y-48*s,x+15*s,y-45*s,x+2*s,y-40*s),Color.rgb(184,47,42))
    }
    private fun drawFarm(canvas: Canvas, x: Float, y: Float, s: Float) {
        diamond(canvas,x,y,42*s,21*s,Color.rgb(145,105,56),Color.rgb(102,75,43))
        for (i in -2..2) {
            stroke(Color.rgb(88,124,49),2*s)
            canvas.drawLine(x+i*6*s,y-5*s,x+i*6*s,y+5*s,paint)
        }
        fill(Color.rgb(88,145,60))
        for (i in -1..1) canvas.drawCircle(x+i*9*s,y-4*s,2.3f*s,paint)
    }
    private fun drawLumber(canvas: Canvas, x: Float, y: Float, s: Float) {
        drawTree(canvas,x-7*s,y+2*s,.7f*s)
        fill(Color.rgb(129,83,47)); canvas.drawRect(x+3*s,y-5*s,x+17*s,y+1*s,paint)
        fill(Color.rgb(194,151,91)); canvas.drawCircle(x+17*s,y-2*s,3*s,paint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w=width.toFloat(); val h=height.toFloat()
        if(w<=0f || h<=0f) return
        canvas.drawColor(Color.rgb(35,57,66))
        // sky / distant horizon
        fill(Color.rgb(112,174,195)); canvas.drawRect(0f,0f,w,h*.43f,paint)
        fill(Color.rgb(78,126,92))
        val hills=Path().apply {
            moveTo(0f,h*.36f); cubicTo(w*.17f,h*.2f,w*.25f,h*.4f,w*.43f,h*.29f)
            cubicTo(w*.63f,h*.17f,w*.78f,h*.39f,w,h*.25f); lineTo(w,h*.55f); lineTo(0f,h*.55f); close()
        }
        canvas.drawPath(hills,paint)
        fill(Color.rgb(91,142,76)); canvas.drawRect(0f,h*.42f,w,h,paint)

        tileW=min(w/(cols+2)*1.52f,h/(rows+2)*1.38f)
        tileH=tileW*.52f
        mapOriginX=w*.50f
        mapOriginY=h*.31f
        // draw isometric tile field, farther tiles first
        for(sum in 0..(cols+rows-2)) {
            for(x in 0 until cols) {
                val y=sum-x
                if(y !in 0 until rows) continue
                val (cx,cy)=iso(x,y)
                val base = when((x*7+y*11)%6) {
                    0 -> Color.rgb(111,159,81)
                    1 -> Color.rgb(119,166,86)
                    2 -> Color.rgb(105,151,76)
                    3 -> Color.rgb(127,169,91)
                    4 -> Color.rgb(113,157,79)
                    else -> Color.rgb(121,161,82)
                }
                diamond(canvas,cx,cy,tileW,tileH,base,Color.rgb(83,125,68))
                if((x*3+y*5)%13==0 && buildings[x to y]==null) drawTree(canvas,cx,cy+2f,.65f)
                when(buildings[x to y]) {
                    1 -> drawCastle(canvas,cx,cy+2f, min(tileW/65f,1.18f))
                    2 -> drawHouse(canvas,cx,cy+1f,min(tileW/48f,1.2f))
                    3 -> drawFarm(canvas,cx,cy+4f,min(tileW/48f,1.2f))
                    4 -> drawLumber(canvas,cx,cy+1f,min(tileW/48f,1.2f))
                }
            }
        }
        // HUD panel
        rr(canvas,RectF(12f,10f,w-12f,h*.135f),18f,Color.argb(230,27,40,48))
        txt(canvas,"KINGDOMS & LORDS  •  HD REMASTER",28f,39f,min(w,h)*.041f)
        txt(canvas,"EMAS  $gold     MAKANAN  $food     KAYU  $wood     PASUKAN  $troops",
            28f,h*.105f,min(w,h)*.027f,Color.rgb(255,232,173))
        // bottom actions
        val labels=listOf("RUMAH  -50 KAYU","LADANG  -40 EMAS","PASUKAN  -30 MAKANAN","SERBU BANDIT")
        val bw=w*.205f; val gap=w*.012f; val start=(w-(bw*4+gap*3))/2f
        val top=h*.83f
        labels.forEachIndexed { i,label ->
            val rect=RectF(start+i*(bw+gap),top,start+i*(bw+gap)+bw,top+h*.12f)
            rr(canvas,rect,12f,if(i==3) Color.rgb(143,57,48) else Color.rgb(40,76,86))
            fill(Color.WHITE); paint.textSize=min(w,h)*.023f; paint.typeface=Typeface.DEFAULT_BOLD
            val tw=paint.measureText(label)
            canvas.drawText(label,rect.centerX()-tw/2,rect.centerY()+paint.textSize*.35f,paint)
        }
        val msg=if(System.currentTimeMillis()<toastUntil) toast else "Ketuk tombol untuk mengelola kerajaan"
        txt(canvas,msg,w*.03f,h*.79f,min(w,h)*.024f,Color.WHITE)
    }

    private fun notify(msg:String) {
        toast=msg; toastUntil=System.currentTimeMillis()+2600; invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if(event.action==MotionEvent.ACTION_UP) {
            val w=width.toFloat(); val h=height.toFloat()
            val bw=w*.205f; val gap=w*.012f; val start=(w-(bw*4+gap*3))/2f; val top=h*.83f
            if(event.y>=top) {
                val idx=((event.x-start)/(bw+gap)).toInt()
                when(idx) {
                    0 -> if(wood>=50) { wood-=50; houses++; val spot=findFreeTile(); if(spot!=null) buildings[spot]=2; notify("Rumah baru dibangun!") } else notify("Kayu belum cukup.")
                    1 -> if(gold>=40) { gold-=40; farms++; val spot=findFreeTile(); if(spot!=null) buildings[spot]=3; notify("Ladang baru dibangun!") } else notify("Emas belum cukup.")
                    2 -> if(food>=30) { food-=30; troops+=3; notify("3 pasukan berhasil direkrut!") } else notify("Makanan belum cukup.")
                    3 -> if(troops>=3) { troops-=3; gold+=65; food+=25; notify("Menang! Rampasan +65 emas.") } else notify("Butuh minimal 3 pasukan.")
                }
            } else if(event.y>h*.17f && event.y<h*.78f) {
                notify("Lahan kerajaan: pilih bangunan dari panel bawah.")
            }
            return true
        }
        return true
    }

    private fun findFreeTile(): Pair<Int,Int>? {
        for(y in 0 until rows) for(x in 0 until cols) {
            if(buildings[x to y]==null && (x*3+y*5)%13!=0) return x to y
        }
        return null
    }
}

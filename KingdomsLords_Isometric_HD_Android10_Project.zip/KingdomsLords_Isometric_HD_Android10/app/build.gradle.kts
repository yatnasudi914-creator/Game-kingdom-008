plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kingdomslords.isometric"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kingdomslords.isometric"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.2-isometric-prototype"
    }
}
